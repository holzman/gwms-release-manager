#!/usr/bin/python

# this is just a set of stubs for python-ldap so pylint tests pass.

class LDAPError(Exception):
    pass


class ldap_obj:
    def search_s(self, arg1, arg2, arg3):
        pass
    def simple_bind(self, arg1, arg2):
        pass

SCOPE_SUBTREE = 'foo'
RES_SEARCH_ENTRY = 'foo'
FILTER_ERROR = LDAPError()

def initialize(arg1):
    return None

def open(arg1, arg2):
    return ldap_obj()



