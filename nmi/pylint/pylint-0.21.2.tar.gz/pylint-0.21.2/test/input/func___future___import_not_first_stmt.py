"""a docstring"""

__revision__ = 1
from __future__ import generators

