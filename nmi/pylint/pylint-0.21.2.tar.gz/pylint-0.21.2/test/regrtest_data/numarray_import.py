"""#10077"""

__revision__ = 1

from numarray import zeros

zeros(shape=(4, 5))
